package hands;


import static org.junit.jupiter.api.Assertions.assertEquals;
import java.util.HashSet;
import java.util.Set;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import cardgame7.Hand;
import cardgame7.Hand.Card;

public class PlayerCardsTest {
	
	  @DisplayName("High Card")
	  @Test
	  public void testHighCard() {
		  
		 Set<Card> cards= new HashSet<Card>();
		 cards.add(Card.ACE_CLUBS);
		 cards.add(Card.SEVEN_CLUBS);
		 cards.add(Card.EIGHT_DIAMONDS);
		 cards.add(Card.TWO_DIAMONDS);
		 cards.add(Card.FOUR_DIAMONDS);
		
		 Hand highHand=new Hand(cards,"Sri");			 
		 assertEquals("HIGH_CARD", highHand.category.toString());

		
	  }
	  
	  @DisplayName("One Pair")
	  @Test
	  public void testOnePair() {
		  
		 Set<Card> pairOfCards= new HashSet<Card>();
		 pairOfCards.add(Card.ACE_CLUBS);
		 pairOfCards.add(Card.ACE_HEARTS);
		 pairOfCards.add(Card.EIGHT_DIAMONDS);
		 pairOfCards.add(Card.TWO_DIAMONDS);
		 pairOfCards.add(Card.FOUR_DIAMONDS);
		
		 Hand highHand=new Hand(pairOfCards,"Sri");			 
		 assertEquals("ONE_PAIR", highHand.category.toString());

		
	  }
	  
	  
	  @DisplayName("Two Pair")
	  @Test
	  public void testTwoPair() {
		  
		 Set<Card> twoPairOfCards= new HashSet<Card>();
		 twoPairOfCards.add(Card.ACE_CLUBS);
		 twoPairOfCards.add(Card.ACE_HEARTS);
		 twoPairOfCards.add(Card.EIGHT_DIAMONDS);
		 twoPairOfCards.add(Card.EIGHT_HEARTS);
		 twoPairOfCards.add(Card.FOUR_DIAMONDS);
		
		 Hand highHand=new Hand(twoPairOfCards,"Sri");			 
		 assertEquals("TWO_PAIR", highHand.category.toString());

		
	  }
	
	  @DisplayName("Three of Kind")
	  @Test
	  public void testThreeOfKind() {
		  
		 Set<Card> threeOfKindCards= new HashSet<Card>();
		 threeOfKindCards.add(Card.ACE_CLUBS);
		 threeOfKindCards.add(Card.ACE_HEARTS);
		 threeOfKindCards.add(Card.ACE_DIAMONDS);
		 threeOfKindCards.add(Card.EIGHT_HEARTS);
		 threeOfKindCards.add(Card.FOUR_DIAMONDS);
		
		 Hand highHand=new Hand(threeOfKindCards,"Sri");			 
		 assertEquals("THREE_OF_A_KIND", highHand.category.toString());

		
	  }
	  
	  
	  
	  @DisplayName("Straight")
	  @Test
	  public void testStraight() {
		  
		 Set<Card> straightCards= new HashSet<Card>();
		 straightCards.add(Card.SEVEN_CLUBS);
		 straightCards.add(Card.EIGHT_HEARTS);
		 straightCards.add(Card.SIX_DIAMONDS);
		 straightCards.add(Card.FIVE_HEARTS);
		 straightCards.add(Card.FOUR_DIAMONDS);
		
		 Hand highHand=new Hand(straightCards,"Sri");			 
		 assertEquals("STRAIGHT", highHand.category.toString());

		
	  }
	  	  
	  @DisplayName("Flush")
	  @Test
	  public void testFlush() {
		  
		 Set<Card> flushCards= new HashSet<Card>();
		 flushCards.add(Card.JACK_CLUBS);
		 flushCards.add(Card.TWO_CLUBS);
		 flushCards.add(Card.SIX_CLUBS);
		 flushCards.add(Card.ACE_CLUBS);
		 flushCards.add(Card.FOUR_CLUBS);
		
		 Hand highHand=new Hand(flushCards,"Sri");			 
		 assertEquals("FLUSH", highHand.category.toString());

		
	  }
	  
	  	  
	  @DisplayName("Full House")
	  @Test
	  public void testFullHouse() {
		  
		 Set<Card> fullHouseCards= new HashSet<Card>();
		 fullHouseCards.add(Card.JACK_CLUBS);
		 fullHouseCards.add(Card.JACK_HEARTS);
		 fullHouseCards.add(Card.JACK_DIAMONDS);
		 fullHouseCards.add(Card.ACE_CLUBS);
		 fullHouseCards.add(Card.ACE_SPADES);
		
		 Hand highHand=new Hand(fullHouseCards,"Sri");			 
		 assertEquals("FULL_HOUSE", highHand.category.toString());

		
	  }
	  
	  
	  @DisplayName("Four of a kind")
	  @Test
	  public void testFourOfKind() {
		  
		 Set<Card> fourOfKindCards= new HashSet<Card>();
		 fourOfKindCards.add(Card.JACK_CLUBS);
		 fourOfKindCards.add(Card.JACK_HEARTS);
		 fourOfKindCards.add(Card.JACK_DIAMONDS);
		 fourOfKindCards.add(Card.JACK_SPADES);
		 fourOfKindCards.add(Card.ACE_SPADES);
		
		 Hand highHand=new Hand(fourOfKindCards,"Sri");			 
		 assertEquals("FOUR_OF_A_KIND", highHand.category.toString());

		
	  }
	  
	  	  
	  @DisplayName("Straight Flush")
	  @Test
	  public void testStraightFlush() {
		  
		 Set<Card> straightFlushCards= new HashSet<Card>();
		 straightFlushCards.add(Card.ACE_CLUBS);
		 straightFlushCards.add(Card.TWO_CLUBS );
		 straightFlushCards.add(Card.THREE_CLUBS);
		 straightFlushCards.add(Card.FOUR_CLUBS);
		 straightFlushCards.add(Card.FIVE_CLUBS);
		
		 Hand highHand=new Hand(straightFlushCards,"Sri");			 
		 assertEquals("STRAIGHT_FLUSH", highHand.category.toString());

		
	  }
	  
}
