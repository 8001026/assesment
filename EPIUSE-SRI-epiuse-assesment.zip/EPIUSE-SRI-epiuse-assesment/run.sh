echo "Shuffling ... Shuffling ... Shuffling ..."

java -jar poker-card-draw.jar
